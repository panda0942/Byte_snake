
public class restartSnake {
	snakepanel panel = new snakepanel();
	
	
	restartSnake(){
		panel.startGame();
	}
	
	
	
	public static void main(String[] args) {
	
		
		

	}

}
