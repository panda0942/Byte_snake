public class snakeGame {
	public static void main(String[] args) {
	// 	 new gameFrame();
	}
}
