import javax.swing.JFrame;
public class gameFrame {
	public gameFrame() {
	  	JFrame hello  = new JFrame();
		
		snakepanel panel = new snakepanel();
		hello.setTitle("Snake Game");
		hello.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    hello.add(panel);
		hello.setResizable(false);
		hello.pack();
		hello.setVisible(true);
		hello.setLocationRelativeTo(null);
	}
}
